package com.example.venteDeVoitures.advertiser.loginRegister;

public interface SwitchLoginRegister {
    public void callBack(int c);
}
