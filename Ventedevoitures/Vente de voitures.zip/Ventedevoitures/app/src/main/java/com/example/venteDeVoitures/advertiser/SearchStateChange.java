package com.example.venteDeVoitures.advertiser;

public interface SearchStateChange {
    void setSearchState(int state);
}
