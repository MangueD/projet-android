package com.example.venteDeVoitures.roomDB;

import androidx.room.Dao;

@Dao
public interface ClientDAO {
}
