package com.example.venteDeVoitures.advertiser.fragments.search;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

import com.example.venteDeVoitures.R;
import com.example.venteDeVoitures.advertiser.AdvertiserMainActivity;
import com.example.venteDeVoitures.advertiser.SearchStateChange;

public class SearchFragmentAdvertiser extends Fragment implements View.OnClickListener {
    private SearchStateChange searchState;
    private ResultFragment resultFragment;
    private Button researchBt;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.advertiser_fragment_search, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle bundle){
        searchState = (AdvertiserMainActivity)getActivity();
        researchBt = view.findViewById(R.id.advertiser_fragment_search_button);
        researchBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchState.setSearchState(AdvertiserMainActivity.SEARCHING);
            }
        });
        view.findViewById(R.id.advertiser_fragment_search_1000).setOnClickListener((View.OnClickListener) this);
        view.findViewById(R.id.advertiser_fragment_search_100000).setOnClickListener((View.OnClickListener) this);
        view.findViewById(R.id.advertiser_fragment_search_10000km).setOnClickListener((View.OnClickListener) this);
        view.findViewById(R.id.advertiser_fragment_search_50000km).setOnClickListener((View.OnClickListener) this);
        view.findViewById(R.id.advertiser_fragment_search_peugeot).setOnClickListener((View.OnClickListener) this);
        view.findViewById(R.id.advertiser_fragment_search_renault).setOnClickListener((View.OnClickListener) this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case(R.id.advertiser_fragment_search_1000):
                resultFragment.setArgs("Toyota", "");
                searchState.setSearchState(AdvertiserMainActivity.RESULT);
                break;
            case(R.id.advertiser_fragment_search_100000):
                resultFragment.setArgs("Audi", "");
                searchState.setSearchState(AdvertiserMainActivity.RESULT);
                break;
            case(R.id.advertiser_fragment_search_10000km):
                resultFragment.setArgs("Tesla", "");
                searchState.setSearchState(AdvertiserMainActivity.RESULT);
                break;
            case(R.id.advertiser_fragment_search_50000km):
                resultFragment.setArgs("Bugatti", "");
                searchState.setSearchState(AdvertiserMainActivity.RESULT);
                break;
            case(R.id.advertiser_fragment_search_peugeot):
                resultFragment.setArgs("Peugeot", "");
                searchState.setSearchState(AdvertiserMainActivity.RESULT);
                break;
            case(R.id.advertiser_fragment_search_renault):
                resultFragment.setArgs("Renault", "");
                searchState.setSearchState(AdvertiserMainActivity.RESULT);
                break;
        }
    }

    public void setResultFragment(ResultFragment r){
        this.resultFragment = r;
    }
}