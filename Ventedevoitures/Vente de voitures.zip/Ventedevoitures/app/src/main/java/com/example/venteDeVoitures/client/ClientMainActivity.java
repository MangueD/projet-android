package com.example.venteDeVoitures.client;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.venteDeVoitures.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class ClientMainActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    HomeFragmentClient homeFragment;
    SavedAdvertsFragment savedAdvertsFragment;
    SearchFragmentClient searchFragment;
    NotificationFragment notificationFragment;
    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.client_activity_main);
        homeFragment = new HomeFragmentClient();
        savedAdvertsFragment = new SavedAdvertsFragment();
        searchFragment = new SearchFragmentClient();
        notificationFragment = new NotificationFragment();
        fragmentManager = getSupportFragmentManager();
        bottomNavigationView = findViewById(R.id.client_bottom_navigation);

        fragmentManager.beginTransaction().replace(R.id.client_container, homeFragment).commit();

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch(item.getItemId()){
                    case R.id.client_item_home:{
                        fragmentManager.beginTransaction().replace(R.id.client_container, homeFragment).commit();
                        return true;
                    }
                    case R.id.client_item_search:{
                        fragmentManager.beginTransaction().replace(R.id.client_container, searchFragment).commit();
                        return true;
                    }
                    case R.id.client_item_savedadverts:{
                        fragmentManager.beginTransaction().replace(R.id.client_container, savedAdvertsFragment).commit();
                        return true;
                    }
                    case R.id.client_item_notification:{
                        fragmentManager.beginTransaction().replace(R.id.client_container, notificationFragment).commit();
                        return true;
                    }
                }
                return false;
            }
        });



    }
}